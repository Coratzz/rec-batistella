package coratto;

import coratto.model.Produto;

public class main {
        public static void main(String[] args){


            Produto produto1 = new Produto();

              produto1.setNome("suco de bambu");
            produto1.setPreco(2037777703);

            System.out.println(produto1);




        }

        }

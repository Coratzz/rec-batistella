package coratto.controller;

public class controller {

//não há nada para ver aqui

}